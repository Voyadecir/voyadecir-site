Voyadecir — Final Logo Pack (from your uploaded logo)

Place these in your repo at assets/img/ (overwrite existing):
- logo.png            (512x512 header)
- logo-1024.png       (large)
- logo-256.png        (medium)
- favicon-32x32.png   (tab icon)
- favicon-16x16.png   (fallback)
- favicon.ico         (legacy)

Steps:
1) GitHub → your site repo → assets/img/ → Upload and replace these files.
2) Commit changes.
3) Hard-refresh the site (Ctrl+Shift+R / Cmd+Shift+R) or try incognito.
